local QBCore = exports['qb-core']:GetCoreObject()
local hasMower = false
local grassProps = {}
local mowingAllowed = false
local houseCooldowns = {}
local selectedLocation = nil
local grassCut = 0

-- Clears all grass props from the world
function ClearGrassProps()
    for _, grass in ipairs(grassProps) do
        if DoesEntityExist(grass) then
            local blip = GetBlipFromEntity(grass)
            if DoesBlipExist(blip) then
                RemoveBlip(blip)
            end
            DeleteObject(grass)
        end
    end
    grassProps = {}
end

-- Spawn grass props around the designated coordinates
function SpawnGrass(grassCoords)
    ClearGrassProps()
    for i = 1, 15 do
        local offset = vector3(math.random(-5, 5), math.random(-5, 5), 0)
        local spawnPoint = vector3(grassCoords.x + offset.x, grassCoords.y + offset.y, grassCoords.z)
        local grass = CreateObject(GetHashKey("prop_veg_grass_01_c"), spawnPoint.x, spawnPoint.y, spawnPoint.z, false, true, true)
        SetEntityHeading(grass, math.random(0, 360))
        local blip = AddBlipForEntity(grass)
        SetBlipSprite(blip, 469)
        SetBlipColour(blip, 2)
        SetBlipScale(blip, 0.7)
        table.insert(grassProps, grass)
    end
    QBCore.Functions.Notify('Grass props spawned. Start mowing!', 'primary')
end

-- Request permission to mow the lawn at a specified location
function RequestMowingPermission(location)
    local currentTime = GetGameTimer()
    if houseCooldowns[location.houseCoords] and currentTime < houseCooldowns[location.houseCoords] then
        QBCore.Functions.Notify('You have recently mowed this lawn. Please wait before mowing again.', 'error')
        return
    end
    selectedLocation = location
    TriggerServerEvent('qb-lawnmower:requestPermission', location.houseCoords)
end

-- Handle the response for mowing permission from the server
RegisterNetEvent('qb-lawnmower:permissionResponse', function(allowed)
    mowingAllowed = allowed
    if allowed then
        SpawnGrass(selectedLocation.grassCoords)
        QBCore.Functions.Notify('Permission granted. Start mowing!', 'primary')
    else
        QBCore.Functions.Notify('Permission denied. Try another house.', 'error')
    end
end)

-- Monitor player inputs for mower interaction and mowing actions
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        if IsControlJustReleased(0, 104) then  -- E key
            if not hasMower then
                local rumpo = GetClosestVehicle(coords, 10.0, GetHashKey("rumpo"), 70)
                if rumpo and #(coords - GetEntityCoords(rumpo)) < 5.0 then
                    -- Spawn the mower vehicle
                    local mowerModel = GetHashKey("mower")
                    RequestModel(mowerModel)
                    while not HasModelLoaded(mowerModel) do
                        Citizen.Wait(10)
                    end
                    local mower = CreateVehicle(mowerModel, GetOffsetFromEntityInWorldCoords(rumpo, 0, -5.0, 0), GetEntityHeading(rumpo), true, false)
                    SetPedIntoVehicle(ped, mower, -1)
                    hasMower = true
                    TriggerEvent('vehiclekeys:client:SetVehicleOwner', GetVehicleNumberPlateText(mower))
                    QBCore.Functions.Notify('Mower spawned. Go to a house and press H to request permission.', 'primary')
                end
            elseif hasMower then
                -- Check proximity to house locations for mowing
                for _, location in pairs(Config.Locations) do
                    if #(coords - location.houseCoords) < 20.0 then
                        RequestMowingPermission(location)
                        break
                    end
                end
            end
        elseif IsControlJustReleased(0, 47) and hasMower then  -- G key to return mower
            local mower = GetVehiclePedIsUsing(ped)
            if mower and GetEntityModel(mower) == GetHashKey("mower") then
                DeleteVehicle(mower)
                hasMower = false
                QBCore.Functions.Notify('Mower returned.', 'success')
            end
        end
    end
end)

-- Monitor grass cutting
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500)
        if hasMower and mowingAllowed then
            local ped = PlayerPedId()
            local mower = GetVehiclePedIsUsing(ped)
            for i = #grassProps, 1, -1 do
                local grass = grassProps[i]
                if grass and DoesEntityExist(grass) and #(GetEntityCoords(mower) - GetEntityCoords(grass)) < 2.5 then
                    DeleteObject(grass)
                    table.remove(grassProps, i)
                    grassCut = grassCut + 1
                    QBCore.Functions.Notify('Grass cut: ' .. grassCut, 'primary')
                    if #grassProps == 0 then
                        mowingAllowed = false
                        TriggerServerEvent('qb-lawnmower:jobCompleted', selectedLocation, grassCut)
                        grassCut = 0  -- Reset the count
                        QBCore.Functions.Notify('Mowing complete. You are paid for the job.', 'success')
                        houseCooldowns[selectedLocation.houseCoords] = GetGameTimer() + 600000  -- 10 minute cooldown
                    end
                end
            end
        end
    end
end)

-- Debug command to check current states
RegisterCommand('debugMower', function()
    print('Mower Status: ' .. tostring(hasMower))
    print('Grass Props: ' .. tostring(#grassProps))
    print('Mowing Allowed: ' .. tostring(mowingAllowed))
end, false)
