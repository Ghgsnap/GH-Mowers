Config = {}
Config.Locations = {
    {
        houseCoords = vector3(333.31, -1741.21, 29.73),
        grassCoords = vector3(316.37, -1728.66, 27.37),
        minPayment = 250,
        maxPayment = 750
    },
    {
        houseCoords = vector3(299.79, -1787.17, 28.44),
        grassCoords = vector3(280.44, -1771.63, 26.17),
        minPayment = 350,
        maxPayment = 650
    },
    {
        houseCoords = vector3(325.93, -1763.31, 29.06),
        grassCoords = vector3(301.29, -1745.75, 27.29),
        minPayment = 350,
        maxPayment = 780
    },
    {
        houseCoords = vector3(-830.38, 115.05, 56.04),
        grassCoords = vector3(-793.71, 115.35, 54.31),
        minPayment = 2000,
        maxPayment = 3000
    }
    -- Additional locations can be added here
}

return Config
