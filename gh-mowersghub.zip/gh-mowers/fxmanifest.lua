fx_version 'cerulean'
game 'gta5'

description 'QB-Core Lawn Mowing Job'

author 'Grindhard Snap'

version '1.0.0'


shared_script 'config.lua'  -- Shared configuration settings
shared_script '@ox_lib/init.lua'

client_script 'client/cl_lawnmower.lua'   -- Main client logic for lawn mowing
         -- Client logic for hiring NPCs


server_script   'server/sv_lawnmower.lua'   -- Main server logic for lawn mowing
     

dependencies {
    'qb-core',
    'ox_lib'    -- Core dependency for the QB framework
 }

 lua54 'yes'
