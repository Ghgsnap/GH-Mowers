local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('qb-lawnmower:requestPermission')
AddEventHandler('qb-lawnmower:requestPermission', function(houseId)
    local src = source
    local allowed = math.random() > 0.4 -- 60% chance to get permission
    TriggerClientEvent('qb-lawnmower:permissionResponse', src, allowed, houseId)
end)

RegisterNetEvent('qb-lawnmower:jobCompleted')
AddEventHandler('qb-lawnmower:jobCompleted', function(location)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local payout = math.random(location.minPayment, location.maxPayment)
        Player.Functions.AddMoney('bank', payout, "Mowed lawn at " .. tostring(location.houseCoords))
        TriggerClientEvent('QBCore:Notify', src, "Payment received: $" .. payout, "success")
    end
end)
